#include <linux/ftrace.h>
#include <linux/kernel.h>
#include <linux/linkage.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/kprobes.h>

#include "common.h"

static struct ftrace_hook demo_hooks[] = {
	// HOOK("do_renameat2",  my_do_renameat2,  &ori_do_renameat2),
};

/******************* COMMON CODES HERE ****************************/
extern void fh_remove_hooks(struct ftrace_hook *hooks, size_t count);
extern int fh_install_hooks(struct ftrace_hook *hooks, size_t count);
/******************* COMMON CODES END ****************************/

static int __init my_hook_init(void)
{
	int err;
/******************* COMMON CODES HERE ****************************/
	err = fh_install_hooks(demo_hooks, ARRAY_SIZE(demo_hooks));
	if (err)
		return err;
/******************* COMMON CODES END ****************************/
	return 0;
}

static void __exit my_hook_exit(void)
{
/******************* COMMON CODES HERE ****************************/
	fh_remove_hooks(demo_hooks, ARRAY_SIZE(demo_hooks));
/******************* COMMON CODES END ****************************/
}

MODULE_LICENSE("GPL");