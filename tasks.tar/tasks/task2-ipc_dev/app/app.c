#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define FILE	"/dev/ipc_dev" // 刚才mknod创建的设备文件名 双引号不要漏
int main(void)
{
	int fd = -1;
    char buf[100];
	fd = open(FILE, O_RDWR);
	if (fd < 0){
		printf("open %s error.\n", FILE);
		return -1;
	}
	printf("open %s success..\n", FILE);

	// 读写文件	
    write(fd,"helloworld",10);
    int readcnt = read(fd,buf,100);//最后一个参数为要读取的字节数
    printf("Read Count is:%d, Data:%s\n", readcnt, buf);

	// 关闭文件
	close(fd);	
	return 0;
}