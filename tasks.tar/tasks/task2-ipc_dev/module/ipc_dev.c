#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/device.h>  
#include <linux/fs.h>
#include <linux/uaccess.h>

#define MYNMAJOR  200
#define MYNAME    "ipc_dev"

char kbuf[100];//内核空间的一个buf
static ssize_t ipc_write(struct file *file, const char __user *ubuf,	size_t count, loff_t *ppos)
{
    int ret = -1;
    printk(KERN_INFO "ipc read\n");
    //使用该函数将应用层的传过来的ubuf中的内容拷贝到驱动空间(内核空间)的一个buf中
    //memcpy(kbuf,ubuf);     //不行，因为2个不在一个地址空间中
    memset(kbuf, 0, sizeof(kbuf));
    ret = copy_from_user(kbuf,ubuf,count);
    if(ret){
        printk(KERN_ERR "copy_from_user fail\n");
        return -EINVAL;//在真正的的驱动中没复制成功应该有一些纠错机制，这里我们简单点
    }
    printk(KERN_ERR "copy_from_user success..\n");
    //到这里我们就成功把用户空间的数据转移到内核空间了

    return 0;
}

ssize_t ipc_read(struct file *file, char __user *ubuf, size_t size, loff_t *ppos)
{
    int ret = -1;
    printk(KERN_INFO "ipc read\n");

    ret = copy_to_user(ubuf,kbuf,size);
    if(ret){
        printk(KERN_ERR "copy_to_user fail\n");
        return -EINVAL;//在真正的的驱动中没复制成功应该有一些纠错机制，这里我们简单点
    }
    printk(KERN_ERR "copy_to_user success..\n");

    return size;
}

//file_operations结构体变量中填充的函数指针的实体，函数的格式要遵守
static int ipc_open(struct inode *inode, struct file *file)
{
    //这个函数中真正应该放置的是打开这个设备的硬件操作代码部分
    //但是现在我们暂时写不了那么多，所以就就用一个printk打印个信息来做代表 
    printk(KERN_INFO "ipc dev open\n");
	return 0;
}

static int ipc_release(struct inode *inode, struct file *file)
{
    printk(KERN_INFO "ipc dev release\n");
    return 0;
}

//自定义一个file_operations结构体变量，并填充
static const struct file_operations ipc_module_fops = {
	.owner		= THIS_MODULE,         //惯例，所有的驱动都有这一个，这也是这结构体中唯一一个不是函数指针的元素
	.open		  = ipc_open,    //将来应用open打开这个这个设备时实际调用的函数
	.read		  = ipc_read,    //将来应用open打开这个这个设备时实际调用的函数
	.write		  = ipc_write,    //将来应用open打开这个这个设备时实际调用的函数
	.release	= ipc_release,   //对应close，为什么不叫close呢？详见后面release和close的区别的讲解
};

/*********************************************************************************/
// 模块安装函数
static int __init ipc_init(void)
{
    printk(KERN_INFO "ipc dev init\n");

    //在module_init宏调用的函数中去注册字符设备驱动
    int ret = -1;     //register_chrdev 返回值为int类型
    ret = register_chrdev(MYNMAJOR, MYNAME, &ipc_module_fops);
    //参数：主设备号major，设备名称name,自己定义好的file_operations结构体变量指针，注意是指针，所以要加上取地址符
    //完了之后检查返回值
    if(ret){
        printk(KERN_ERR "register ipc dev failed\n");  //注意这里不再用KERN_INFO
        return -EINVAL; //内核中定义了好多error number 不都用以前那样return -1;负号要加 ！！
    }
    memset(kbuf, 0, 100);
    printk(KERN_INFO "register ipc dev success...\n");
    return 0;
}

// 模块卸载函数
static void __exit ipc_exit(void)
{
    printk(KERN_INFO "ipc dev exit\n");
    //在module_exit宏调用的函数中去注销字符设备驱动
    //实验中，在我们这里不写东西的时候，rmmod 后lsmod 查看确实是没了，但是cat /proc/device发现设备号还是被占着
    unregister_chrdev(MYNMAJOR, MYNAME);  //参数就两个
    //检测返回值
    return 0;
}
/*********************************************************************************/

module_init(ipc_init);
module_exit(ipc_exit);

MODULE_AUTHOR("myname@huawei.com");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("A IPC Dev Module");