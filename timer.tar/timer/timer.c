#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/timer.h>
#include <linux/init.h>
//#include <linux/jiffies.h>
//#include <linux/slab.h>

struct timer_list my_timer;

void my_timer_func(void);

void my_timer_init(void)
{
    init_timer_key(&my_timer, (void*)my_timer_func, TIMER_DEFERRABLE, "my timer", NULL);
    //my_timer.expires = jiffies + HZ;
    //my_timer.function = (void*)my_timer_func;
    add_timer(&my_timer);
}

void my_timer_func(void)
{
    static int cnt = 0;
    cnt++;
    printk("My timer func %d\n", cnt);
    mod_timer(&my_timer, jiffies+HZ);
}

static int __init timer_init(void)
{
    my_timer_init();
    printk("Hello world from the timer module\n");
    return 0;
}

static void __exit timer_exit(void)
{
    del_timer(&my_timer);
    printk("Goodbye, world! Timer module exit\n");
}

module_init(timer_init);
module_exit(timer_exit);

MODULE_AUTHOR("myname@huawei.com");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("A timer Module");
